package com.webage.rest.dao;

import org.springframework.stereotype.Repository;

import com.webage.rest.model.Employee;
import com.webage.rest.model.Employees;

@Repository
public class EmployeeDAO
{
    private static Employees list = new Employees();

    static
    {
        list.getEmployeeList().add(new Employee(1, "Alice", "Smith", "alices@gmail.com"));
        list.getEmployeeList().add(new Employee(2, "David", "Allen", "davidd@gmail.com"));
        list.getEmployeeList().add(new Employee(3, "John", "Doe", "johnd@gmail.com"));
    }

    public Employees getAllEmployees()
    {
        return list;
    }

    public void addEmployee(Employee employee) {
        list.getEmployeeList().add(employee);
    }
}