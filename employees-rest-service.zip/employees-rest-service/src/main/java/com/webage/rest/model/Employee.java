package com.webage.rest.model;
 
public class Employee {
 
    public Employee() {
 
    }
 
    public Employee(Integer id, String firstName, String lastName, String email) {
        super();
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }
  
    private Integer id;
    private String firstName;
    private String lastName;
    private String email;
 
    //Getters and setters
    public Integer getId() {
         return this.id;
    }

    public void setId(Integer _id) {
        this.id = _id;
    }
   public String getFirstName() {
         return this.firstName;
    }

    public void setFirstName(String _firstName) {
        
        this.firstName = _firstName;
    }

   public String getLastName() {
         return this.lastName;
    }

    public void setLastName(String _lastName) {
        this.lastName = _lastName;
    }
   public String getEmail() {
         return this.email;
    }

    public void setEmail(String _email) {
        this.email = _email;
    }

    @Override
    public String toString() {
        return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + "]";
    }
}
